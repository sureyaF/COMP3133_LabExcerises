package assignment_03.COMP3095_The_Team;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Comp3095TheTeamApplication {

	public static void main(String[] args) {
		SpringApplication.run(Comp3095TheTeamApplication.class, args);
	}

}
