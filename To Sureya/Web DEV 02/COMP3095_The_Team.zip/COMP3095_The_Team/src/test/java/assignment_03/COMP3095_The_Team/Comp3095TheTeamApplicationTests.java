package assignment_03.COMP3095_The_Team;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Comp3095TheTeamApplicationTests {

	@Test
	void contextLoads() {
	}

}
