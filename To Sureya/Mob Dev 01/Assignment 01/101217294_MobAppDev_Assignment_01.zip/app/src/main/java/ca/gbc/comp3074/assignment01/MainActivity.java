package ca.gbc.comp3074.assignment01;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //app variables
        final EditText work_hours = (EditText) findViewById(R.id.work_hours);
        final EditText hour_rate = (EditText) findViewById(R.id.hour_rate);
        final TextView warning = (TextView) findViewById(R.id.warning);
        Button calculate = (Button) findViewById(R.id.calculate);
        Button clear = (Button) findViewById(R.id.clear);

        final TextView pay = (TextView) findViewById(R.id.pay);
        final TextView overtime = (TextView) findViewById(R.id.overtime);
        final TextView total_pay = (TextView) findViewById(R.id.total_pay);
        final TextView tax = (TextView) findViewById(R.id.tax);

        calculate.setOnClickListener(new View.OnClickListener() {
            private boolean isEmpty(EditText a) {
                if (a.getText().toString().trim().length() > 0) {
                    return false;//not empty
                } else {
                    return true;//empty
                }
            }
            @Override
            public void onClick(View v) {
                if (isEmpty(work_hours) == true || isEmpty(hour_rate) == true) {
                    warning.setText(" Work hours or hour rate filed is empty ");
                    pay.setText("");
                    tax.setText("");
                    total_pay.setText("");
                    overtime.setText("");
                } else {
                    warning.setText("");
                    int hours = Integer.parseInt(work_hours.getText().toString());
                    float rate = Float.parseFloat(hour_rate.getText().toString());
                    if (hours <= 40) {
                        if (hours <= 0) {
                            warning.setText(" Hours Cannot be less than 0 ");
                            pay.setText("");
                            tax.setText("");
                            total_pay.setText("");
                            overtime.setText("");
                        } else if (rate <= 0) {
                            warning.setText(" Rate Cannot be less than 0 ");
                            pay.setText("");
                            tax.setText("");
                            total_pay.setText("");
                            overtime.setText("");
                        } else {
                            //if (rate <= 0)
                            float paycal = hours * rate;
                            float paytax = (float) (paycal * 0.18);
                            float paytotal = paycal - paytax;
                            pay.setText("Pay Is: " + Float.valueOf(paycal).toString());
                            tax.setText("Tax is: " + Float.valueOf(paytax).toString());
                            total_pay.setText("Total pay is(after tax): " + Float.valueOf(paytotal).toString());
                            overtime.setText("No Overtime");
                        }
                    } else if (hours > 40) {
                        if (rate <= 0) {
                            warning.setText(" Rate Cannot be less than 0 ");
                            pay.setText("");
                            tax.setText("");
                            total_pay.setText("");
                            overtime.setText("");
                        } else {
                            float paycal = (float) ((hours - 40) * rate * 1.5) + (40 * rate);
                            float paytax = (float) (paycal * 0.18);
                            float paytotal = (float) paycal - paytax;
                            float overtimepay = (float) ((hours - 40) * rate * 1.5);
                            pay.setText("Pay Is: " + Float.valueOf(paycal).toString());
                            tax.setText("Tax is: " + Float.valueOf(paytax).toString());
                            total_pay.setText("Total pay is(after tax): " + Float.valueOf(paytotal).toString());
                            overtime.setText("Overtime pay: " + Float.valueOf(overtimepay).toString());
                        }
                    }
                }
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                work_hours.setText(null);
                hour_rate.setText(null);
                warning.setText("");
                pay.setText("");
                tax.setText("");
                total_pay.setText("");
                overtime.setText("");
            }
        });


        //--------------------------------
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.about:
                Intent intent = new Intent(MainActivity.this, About.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


}