import React from 'react';
const Footer = () => {

    return (

            <div className="footer">By Kanta Husari</div>

    )
}
export default Footer