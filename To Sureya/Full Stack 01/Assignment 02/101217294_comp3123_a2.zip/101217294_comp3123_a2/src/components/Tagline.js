import React from 'react';
const Tagline=()=>{

    return(
    <div className="tagline">Enter city name</div>
    
    )
}
export default Tagline