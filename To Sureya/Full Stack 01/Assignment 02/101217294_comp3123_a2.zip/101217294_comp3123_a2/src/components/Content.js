import React from "react";

const Content = (props) => {
    return (
        <div className="conprovider">
            {props.children}
        </div>
    )
}
export default Content