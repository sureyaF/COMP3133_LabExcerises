import React from "react";

const Header = () => {
    return (
        <div className="head">
            <h1>Weather Forecast Web_App</h1>
            <h1>101217294_comp3123_a2 </h1>
            <h1>Fall 2020 </h1>
        </div>
    )
}
export default Header