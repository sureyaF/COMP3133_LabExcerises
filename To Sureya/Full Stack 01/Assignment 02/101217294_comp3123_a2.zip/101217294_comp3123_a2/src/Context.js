import { createContext } from "react";
const Context=createContext();
export default Context