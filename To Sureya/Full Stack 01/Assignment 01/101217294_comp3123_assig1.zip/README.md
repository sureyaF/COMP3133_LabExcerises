This is a simple Node.JS application that receives user requests and return JSON object Data
in terminal:
cd "<Project Directory>"     ↵
npm install express     ↵
node 101217294_comp3123_assig1.js     ↵

in Browser:
localhost:<Port_Number>     ↵